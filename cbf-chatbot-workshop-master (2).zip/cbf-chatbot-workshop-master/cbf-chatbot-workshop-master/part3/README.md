# Chatbots with Node.js and Watson Conversation
## Part 3

This is part 3 of the tutorial delivered at Cognitive Builder Faire.

To run:

1. From the [Data Science Experience](https://datascience.ibm.com) import the notebook in the notebook folder
to a new or existing project.
2. Follow the steps in the notebook.